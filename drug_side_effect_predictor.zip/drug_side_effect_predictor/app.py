from flask import Flask, request, jsonify
import joblib

app = Flask(__name__)

model = joblib.load("side_effect_model.pkl")
le_drug = joblib.load("le_drug.pkl")
le_sex = joblib.load("le_sex.pkl")
side_effect_names = joblib.load("side_effect_names.pkl")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    try:
        drug = le_drug.transform([data["drug"].lower()])[0]
    except:
        return jsonify({"error": "Unknown drug"}), 400

    try:
        sex = le_sex.transform([data["sex"].lower()])[0]
    except:
        return jsonify({"error": "Sex must be 'male' or 'female'"}), 400

    age = int(data.get("age", 30))
    input_vector = [[drug, age, sex]]

    prediction = model.predict(input_vector)[0]
    side_effects = [
        {"name": side_effect_names[i], "risk": "Yes" if p == 1 else "No"}
        for i, p in enumerate(prediction)
    ]

    return jsonify({"side_effects": side_effects})

if __name__ == "__main__":
    app.run(debug=True)
