import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier
import joblib

df = pd.read_csv("dummy_data.csv")

le_drug = LabelEncoder()
le_sex = LabelEncoder()
df["drug"] = le_drug.fit_transform(df["drug"])
df["sex"] = le_sex.fit_transform(df["sex"])

joblib.dump(le_drug, "le_drug.pkl")
joblib.dump(le_sex, "le_sex.pkl")

X = df[["drug", "age", "sex"]]
y = df[["nausea", "headache", "rash"]]

model = MultiOutputClassifier(RandomForestClassifier())
model.fit(X, y)

joblib.dump(model, "side_effect_model.pkl")
joblib.dump(y.columns.tolist(), "side_effect_names.pkl")
